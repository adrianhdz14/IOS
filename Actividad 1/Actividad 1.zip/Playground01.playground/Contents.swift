//: Playground - noun: a place where people can play
//Adrian A. Flores Hdz 2700482

import UIKit
//variable
var v1 = "esto es Swift"

//asigna un numero
let c1 = 4

//represeta un dato tipo string
var cadena:String = String()

//representa la asignacion de dos datos
cadena = "Hola mundo "  + v1

//imprime
print("El contenido es: \(cadena)")
print("El valor de constante es: \(c1)")


